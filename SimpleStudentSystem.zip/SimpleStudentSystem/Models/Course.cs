using System.ComponentModel.DataAnnotations;

namespace SimpleStudentSystem.Models;

public class Course
{
    public int Id { get; set; }

    [Required]
    [StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [StringLength(10)]
    public string Code { get; set; } = string.Empty;

    [Required]
    public int Credits { get; set; }

    [StringLength(500)]
    public string? Description { get; set; }

    public List<StudentCourse> Enrollments { get; set; } = new();
} 