using System;

namespace SimpleStudentSystem.Models;

public static class GradeCalculator
{
    public static double CalculateGPA(decimal numericalGrade)
    {
        return numericalGrade switch
        {
            >= 93 => 4.00,                    // A
            >= 90 and < 93 => 3.67,          // A-
            >= 87 and < 90 => 3.33,          // B+
            >= 83 and < 87 => 3.00,          // B
            >= 80 and < 83 => 2.67,          // B-
            >= 77 and < 80 => 2.33,          // C+
            >= 73 and < 77 => 2.00,          // C
            >= 70 and < 73 => 1.67,          // C-
            >= 60 and < 70 => 1.00,          // D
            _ => 0.00                         // F
        };
    }

    public static string GetLetterGrade(decimal numericalGrade)
    {
        return numericalGrade switch
        {
            >= 93 => "A",
            >= 90 and < 93 => "A-",
            >= 87 and < 90 => "B+",
            >= 83 and < 87 => "B",
            >= 80 and < 83 => "B-",
            >= 77 and < 80 => "C+",
            >= 73 and < 77 => "C",
            >= 70 and < 73 => "C-",
            >= 60 and < 70 => "D",
            _ => "F"
        };
    }
} 