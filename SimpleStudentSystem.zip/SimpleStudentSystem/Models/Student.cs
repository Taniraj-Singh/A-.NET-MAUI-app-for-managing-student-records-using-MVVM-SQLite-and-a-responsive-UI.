using System.ComponentModel.DataAnnotations;

namespace SimpleStudentSystem.Models;

public class Student
{
    public int Id { get; set; }

    [Required]
    [StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required]
    public DateTime DateOfBirth { get; set; }

    [StringLength(20)]
    public string? PhoneNumber { get; set; }

    public string? Address { get; set; }

    [Required]
    public string StudentId { get; set; } = string.Empty;

    [Required]
    public StudentStatus Status { get; set; } = StudentStatus.Active;

    public string? EmergencyContact { get; set; }

    public string? EmergencyPhone { get; set; }

    public DateTime EnrollmentDate { get; set; } = DateTime.Now;

    public List<StudentCourse> Enrollments { get; set; } = new();

    public double GetGPA()
    {
        var completedCourses = Enrollments
            .Where(e => e.Grade.HasValue && e.Status == EnrollmentStatus.Completed)
            .ToList();

        if (!completedCourses.Any()) return 0;

        var totalGradePoints = completedCourses.Sum(e => GradeCalculator.CalculateGPA(e.Grade!.Value));
        return Math.Round(totalGradePoints / completedCourses.Count, 2);
    }

    public string GetLetterGrade(decimal grade)
    {
        return GradeCalculator.GetLetterGrade(grade);
    }

    public IEnumerable<(string CourseName, decimal Grade, string LetterGrade, double GradePoints)> GetGradeReport()
    {
        return Enrollments
            .Where(e => e.Grade.HasValue && e.Status == EnrollmentStatus.Completed)
            .Select(e => (
                CourseName: e.Course.Name,
                Grade: e.Grade!.Value,
                LetterGrade: GetLetterGrade(e.Grade.Value),
                GradePoints: GradeCalculator.CalculateGPA(e.Grade.Value)
            ));
    }
}

public enum StudentStatus
{
    Active,
    Inactive,
    Graduated,
    Suspended
} 