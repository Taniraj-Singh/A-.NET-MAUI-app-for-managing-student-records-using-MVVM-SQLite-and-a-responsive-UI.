using System.ComponentModel.DataAnnotations;

namespace SimpleStudentSystem.Models;

public class StudentCourse
{
    public int StudentId { get; set; }
    public Student Student { get; set; } = null!;

    public int CourseId { get; set; }
    public Course Course { get; set; } = null!;

    public DateTime EnrollmentDate { get; set; } = DateTime.Now;

    [Range(0, 100)]
    public decimal? Grade { get; set; }

    public string? Notes { get; set; }

    public EnrollmentStatus Status { get; set; } = EnrollmentStatus.Enrolled;
}

public enum EnrollmentStatus
{
    Enrolled,
    Completed,
    Withdrawn,
    Failed
} 