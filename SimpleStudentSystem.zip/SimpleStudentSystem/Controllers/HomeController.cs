using Microsoft.AspNetCore.Mvc;
using SimpleStudentSystem.Models;
using SimpleStudentSystem.Services;

namespace SimpleStudentSystem.Controllers;

public class HomeController : Controller
{
    private readonly StudentService _studentService;
    private readonly CourseService _courseService;

    public HomeController(StudentService studentService, CourseService courseService)
    {
        _studentService = studentService;
        _courseService = courseService;
    }

    public IActionResult Index()
    {
        var students = _studentService.GetAll();
        return View(students);
    }

    public IActionResult Create()
    {
        var student = new Student
        {
            EnrollmentDate = DateTime.Now,
            Status = StudentStatus.Active
        };
        return View(student);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Student student)
    {
        if (!ModelState.IsValid)
        {
            return View(student);
        }

        // Generate a unique student ID if not provided
        if (string.IsNullOrEmpty(student.StudentId))
        {
            student.StudentId = GenerateStudentId();
        }

        student.EnrollmentDate = DateTime.Now;
        _studentService.Add(student);

        TempData["SuccessMessage"] = "Student successfully created!";
        return RedirectToAction(nameof(Index));
    }

    public IActionResult Details(int id)
    {
        var student = _studentService.GetById(id);
        if (student == null)
        {
            return NotFound();
        }

        // Load course details for each enrollment
        var courses = _courseService.GetAll();
        foreach (var enrollment in student.Enrollments)
        {
            enrollment.Course = courses.FirstOrDefault(c => c.Id == enrollment.CourseId);
        }

        return View(student);
    }

    public IActionResult Edit(int id)
    {
        var student = _studentService.GetById(id);
        if (student == null)
        {
            return NotFound();
        }
        return View(student);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(int id, Student student)
    {
        if (id != student.Id)
        {
            return NotFound();
        }

        if (!ModelState.IsValid)
        {
            return View(student);
        }

        var existingStudent = _studentService.GetById(id);
        if (existingStudent == null)
        {
            return NotFound();
        }

        // Preserve enrollments from existing student
        student.Enrollments = existingStudent.Enrollments;
        
        _studentService.Update(student);
        TempData["SuccessMessage"] = "Student successfully updated!";
        return RedirectToAction(nameof(Index));
    }

    private string GenerateStudentId()
    {
        var year = DateTime.Now.Year.ToString();
        var students = _studentService.GetAll();
        var count = students.Count + 1;
        return $"{year}{count.ToString().PadLeft(3, '0')}";
    }
} 