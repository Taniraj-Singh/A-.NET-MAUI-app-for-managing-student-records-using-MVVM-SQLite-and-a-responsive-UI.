using Microsoft.AspNetCore.Mvc;
using SimpleStudentSystem.Models;
using SimpleStudentSystem.Services;

namespace SimpleStudentSystem.Controllers;

public class CourseController : Controller
{
    private readonly CourseService _courseService;
    private readonly StudentService _studentService;

    public CourseController(CourseService courseService, StudentService studentService)
    {
        _courseService = courseService;
        _studentService = studentService;
    }

    public IActionResult Index()
    {
        var courses = _courseService.GetAll();
        return View(courses);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Course course)
    {
        if (ModelState.IsValid)
        {
            _courseService.Add(course);
            TempData["SuccessMessage"] = "Course successfully created!";
            return RedirectToAction(nameof(Index));
        }
        return View(course);
    }

    public IActionResult Details(int id)
    {
        var course = _courseService.GetById(id);
        if (course == null)
        {
            return NotFound();
        }

        // Load student details for each enrollment
        foreach (var enrollment in course.Enrollments)
        {
            enrollment.Student = _studentService.GetById(enrollment.StudentId);
        }

        return View(course);
    }

    public IActionResult Enroll(int id)
    {
        var course = _courseService.GetById(id);
        if (course == null)
        {
            return NotFound();
        }

        var students = _studentService.GetAll();
        
        // Filter out already enrolled students
        var availableStudents = students.Where(s => !course.Enrollments.Any(e => e.StudentId == s.Id)).ToList();
        
        if (!availableStudents.Any())
        {
            TempData["WarningMessage"] = "All students are already enrolled in this course.";
            return RedirectToAction(nameof(Details), new { id });
        }

        ViewBag.Students = availableStudents;
        return View(course);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Enroll(int courseId, int studentId)
    {
        var course = _courseService.GetById(courseId);
        var student = _studentService.GetById(studentId);

        if (course == null || student == null)
        {
            TempData["ErrorMessage"] = "Invalid course or student selected.";
            return RedirectToAction(nameof(Index));
        }

        try
        {
            if (course.Enrollments.Any(e => e.StudentId == studentId))
            {
                TempData["WarningMessage"] = $"Student {student.Name} is already enrolled in this course.";
            }
            else
            {
                _courseService.EnrollStudent(courseId, studentId);
                TempData["SuccessMessage"] = $"Successfully enrolled {student.Name} in {course.Name}.";
            }
        }
        catch (Exception ex)
        {
            TempData["ErrorMessage"] = "An error occurred while enrolling the student. Please try again.";
            // Log the error here if you have logging configured
        }

        return RedirectToAction(nameof(Details), new { id = courseId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult UpdateGrade(int courseId, int studentId, decimal grade)
    {
        var course = _courseService.GetById(courseId);
        var student = _studentService.GetById(studentId);

        if (course == null || student == null)
        {
            TempData["ErrorMessage"] = "Invalid course or student selected.";
            return RedirectToAction(nameof(Index));
        }

        try
        {
            if (grade < 0 || grade > 100)
            {
                TempData["ErrorMessage"] = "Grade must be between 0 and 100.";
            }
            else
            {
                _courseService.UpdateGrade(courseId, studentId, grade);
                TempData["SuccessMessage"] = $"Successfully updated grade for {student.Name}.";
            }
        }
        catch (Exception ex)
        {
            TempData["ErrorMessage"] = "An error occurred while updating the grade. Please try again.";
            // Log the error here if you have logging configured
        }

        return RedirectToAction(nameof(Details), new { id = courseId });
    }
} 