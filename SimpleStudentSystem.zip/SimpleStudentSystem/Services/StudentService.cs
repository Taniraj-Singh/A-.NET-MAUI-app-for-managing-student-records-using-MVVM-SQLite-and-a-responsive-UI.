using SimpleStudentSystem.Models;

namespace SimpleStudentSystem.Services;

public class StudentService
{
    private static List<Student> _students = new List<Student>();
    private static int _nextId = 1;
    private static bool _isInitialized = false;

    public StudentService()
    {
        if (!_isInitialized)
        {
            InitializeSampleData();
            _isInitialized = true;
        }
    }

    private void InitializeSampleData()
    {
        var sampleStudents = new[]
        {
            new Student 
            { 
                StudentId = "2024001", 
                Name = "Love", 
                Email = "love@university.edu",
                DateOfBirth = new DateTime(2000, 5, 15),
                PhoneNumber = "123-456-7890",
                Status = StudentStatus.Active,
                Address = "Delhi, India"
            },
            new Student 
            { 
                StudentId = "2024002", 
                Name = "Deepak", 
                Email = "deepak@university.edu",
                DateOfBirth = new DateTime(2001, 3, 21),
                PhoneNumber = "123-456-7891",
                Status = StudentStatus.Active,
                Address = "Mumbai, India"
            },
            new Student 
            { 
                StudentId = "2024003", 
                Name = "Taniraj Singh", 
                Email = "taniraj.singh@university.edu",
                DateOfBirth = new DateTime(1999, 11, 8),
                PhoneNumber = "123-456-7892",
                Status = StudentStatus.Active,
                Address = "Punjab, India"
            },
            new Student 
            { 
                StudentId = "2024004", 
                Name = "Usama", 
                Email = "usama@university.edu",
                DateOfBirth = new DateTime(2000, 7, 12),
                PhoneNumber = "123-456-7893",
                Status = StudentStatus.Active,
                Address = "Lahore, Pakistan"
            },
            new Student 
            { 
                StudentId = "2024005", 
                Name = "Tushar", 
                Email = "tushar@university.edu",
                DateOfBirth = new DateTime(2001, 9, 25),
                PhoneNumber = "123-456-7894",
                Status = StudentStatus.Active,
                Address = "Gujarat, India"
            }
        };

        foreach (var student in sampleStudents)
        {
            Add(student);
        }
    }

    public List<Student> GetAll() => _students;

    public Student? GetById(int id) => _students.FirstOrDefault(s => s.Id == id);

    public void Add(Student student)
    {
        student.Id = _nextId++;
        student.Enrollments = new List<StudentCourse>();
        _students.Add(student);
    }

    public void Update(Student student)
    {
        var existing = _students.FirstOrDefault(s => s.Id == student.Id);
        if (existing != null)
        {
            // Preserve enrollments if not provided in the update
            if (student.Enrollments == null || !student.Enrollments.Any())
            {
                student.Enrollments = existing.Enrollments;
            }
            
            var index = _students.IndexOf(existing);
            _students[index] = student;
        }
    }

    public void Delete(int id)
    {
        var student = _students.FirstOrDefault(s => s.Id == id);
        if (student != null)
        {
            _students.Remove(student);
        }
    }
} 