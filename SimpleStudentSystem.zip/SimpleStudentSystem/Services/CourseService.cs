using SimpleStudentSystem.Models;

namespace SimpleStudentSystem.Services;

public class CourseService
{
    private static List<Course> _courses = new List<Course>();
    private static int _nextId = 1;
    private static bool _isInitialized = false;
    private readonly StudentService _studentService;

    public CourseService(StudentService studentService)
    {
        _studentService = studentService;
        if (!_isInitialized)
        {
            InitializeSampleData();
            _isInitialized = true;
        }
    }

    private void InitializeSampleData()
    {
        var sampleCourses = new[]
        {
            new Course 
            { 
                Code = "CS101", 
                Name = "Introduction to Computer Science",
                Credits = 3,
                Description = "An introductory course covering the fundamentals of computer science, including basic programming concepts, algorithms, and problem-solving techniques."
            },
            new Course 
            { 
                Code = "MATH201", 
                Name = "Advanced Mathematics",
                Credits = 4,
                Description = "A comprehensive course covering calculus, linear algebra, and differential equations with practical applications."
            },
            new Course 
            { 
                Code = "ENG102", 
                Name = "Academic Writing",
                Credits = 3,
                Description = "Develop advanced writing skills for academic and professional contexts, focusing on research papers and analytical essays."
            }
        };

        foreach (var course in sampleCourses)
        {
            Add(course);
        }
    }

    public List<Course> GetAll() => _courses;

    public Course? GetById(int id) => _courses.FirstOrDefault(c => c.Id == id);

    public void Add(Course course)
    {
        course.Id = _nextId++;
        course.Enrollments = new List<StudentCourse>();
        _courses.Add(course);
    }

    public void Update(Course course)
    {
        var existing = _courses.FirstOrDefault(c => c.Id == course.Id);
        if (existing != null)
        {
            course.Enrollments = existing.Enrollments;
            var index = _courses.IndexOf(existing);
            _courses[index] = course;
        }
    }

    public void Delete(int id)
    {
        var course = _courses.FirstOrDefault(c => c.Id == id);
        if (course != null)
        {
            _courses.Remove(course);
        }
    }

    public void EnrollStudent(int courseId, int studentId)
    {
        var course = GetById(courseId);
        var student = _studentService.GetById(studentId);
        
        if (course == null || student == null) return;

        // Check if student is already enrolled
        if (course.Enrollments.Any(e => e.StudentId == studentId))
            return;

        var enrollment = new StudentCourse
        {
            CourseId = courseId,
            Course = course,
            StudentId = studentId,
            Student = student,
            EnrollmentDate = DateTime.Now,
            Status = EnrollmentStatus.Enrolled
        };

        // Add enrollment to course
        course.Enrollments.Add(enrollment);

        // Add enrollment to student
        if (student.Enrollments == null)
        {
            student.Enrollments = new List<StudentCourse>();
        }
        student.Enrollments.Add(enrollment);

        // Update both course and student
        Update(course);
        _studentService.Update(student);
    }

    public void UpdateGrade(int courseId, int studentId, decimal grade)
    {
        var course = GetById(courseId);
        if (course == null) return;

        var enrollment = course.Enrollments.FirstOrDefault(e => e.StudentId == studentId);
        if (enrollment == null) return;

        enrollment.Grade = grade;
        enrollment.Status = grade >= 60 ? EnrollmentStatus.Completed : EnrollmentStatus.Failed;

        // Update the enrollment in the student's record as well
        var student = _studentService.GetById(studentId);
        if (student != null)
        {
            var studentEnrollment = student.Enrollments.FirstOrDefault(e => e.CourseId == courseId);
            if (studentEnrollment != null)
            {
                studentEnrollment.Grade = grade;
                studentEnrollment.Status = enrollment.Status;
                _studentService.Update(student);
            }
        }

        Update(course);
    }
} 